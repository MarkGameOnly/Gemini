# GeminiAI Telegram Bot for Railway

This is a simple Telegram bot that connects to Gemini API and answers any prompt.

## 🚀 How to Deploy on Railway

1. Clone this repository or create a new one on GitHub.
2. Push these files to your GitHub repo.
3. Go to [https://railway.app](https://railway.app)
4. Click "New Project" → "Deploy from GitHub"
5. Set Environment Variables:
   - `TELEGRAM_BOT_TOKEN`
   - `GEMINI_API_KEY`
6. Deploy & Done!

